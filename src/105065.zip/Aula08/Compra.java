package Aula08;

public interface Compra {
    void adicionarProduto(Produto Produto, int quantidade);
    void listarProdutos();
    double calcularTotal();
    
}
