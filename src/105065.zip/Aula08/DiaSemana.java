package Aula08;

public enum DiaSemana {
    Segunda, Terca, Quarta, Quinta, Sexta, Sabado, Domingo
    
}
