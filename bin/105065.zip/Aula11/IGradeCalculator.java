package Aula11;

import java.util.List;

public interface IGradeCalculator {

    double calculate(List<Double> grades);
}
